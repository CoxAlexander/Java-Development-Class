//DemoArrary.java
//9/16/2024
//Alexander Cox

public class DemoArrary{
    public static void main(String[] args) {
        double [] salaries = new double[4];
        salaries[0] = 16.75;
        salaries[1] = 17.55;
        salaries[2] = 18.25;
        salaries[3] = 19.85;

        System.out.println("Salaries one by one are: ");
        System.out.println(salaries[0]);
        System.out.println(salaries[1]);
        System.out.println(salaries[2]);
        System.out.println(salaries[3]);
    }
}