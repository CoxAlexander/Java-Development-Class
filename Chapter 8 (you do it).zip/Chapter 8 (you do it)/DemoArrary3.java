//DemoArrary3.java
//9/16/2024
//Alexander Cox

public class DemoArrary3{
    public static void main(String[] args) {
        double [] salaries = {16.25, 17.55, 18.25, 19.85};
        System.out.println("Salaries one by one are: ");
        for (int x = 0 ; x < salaries.length; ++x)
            System.out.println(salaries[x]);
    }
}