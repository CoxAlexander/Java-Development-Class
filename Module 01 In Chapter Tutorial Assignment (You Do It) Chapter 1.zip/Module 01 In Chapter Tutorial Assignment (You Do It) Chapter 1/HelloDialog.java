//Filename HelloDialog.java
//Written by Alexander Cox
//Written on 8/21/2024

import javax.swing.JOptionPane;
public class HelloDialog {
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Hello, World!");
    }
}