public class JHelloDemo
{
   public static void main(String[] args)
   {
      JHelloFrame frame = new JHelloFrame();
      frame.setVisible(true);
   }
}