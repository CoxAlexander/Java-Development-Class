//Insured.java
//9/23/2024
//Alexander Cox

public interface Insured{
    public abstract void setCoverage();
    public abstract int getCoverage();
    
}