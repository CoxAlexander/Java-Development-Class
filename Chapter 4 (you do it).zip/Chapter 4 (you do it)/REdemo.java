//Alexander Cox
//9/9/2024
//Application for 4-40 p. 152
public class REdemo
{
 public static void main(String[] args)
  {
   RealEstateListing myListing = new RealEstateListing
    (2, 250000, "1212 Mansion Lane", 6700);
   myListing.display();
  }
 }