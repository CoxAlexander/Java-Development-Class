//Filename DataDemo.java
//Written by Alexander Cox
//Written on 8/23/2024
public class DataDemo {
    public static void main(String[] args) {
        int aWholeNumber = 315;
        System.out.print("The number is: ");
        System.out.println(aWholeNumber);
    }
}    