
public class  MovieQuoteInfo {
    public static void main(String [] args) {
        System.out.println( "No, I am your father");
        System.out.println("Star Wars the Emipire Strikes Back");
        System.out.println("Darth Vadar");
        System.out.println("1980");
    }
}
