//TestInfo.java
//Alexander Cox
//8/28/2024
public class TestInfo{
    public static void main(String[]args){
        System.out.println("Calling method from another class:");
        ParadiseInfo.displayInfo();   
    }
}