//ParadiseInfo.Java
//made by Alexander Cox
//8/28/2024


public class ParadiseInfo{
    public static void main(String[] args) {
        displayInfo();
    }
    public static void displayInfo() {
        System.out.println("Paradise Day spa wants to pamper you");
        System.out.println("We will make you look good");
    }
}