//DinnerParty.java
//9/18/2024
//Alexander Cox
public class DinnerParty extends Party{
    private int dinnerChoice;
    public int getDinnerChoice(){
        return dinnerChoice;
    }
    public void setDinnerChoice(int choice){
        dinnerChoice = choice;
    }
}