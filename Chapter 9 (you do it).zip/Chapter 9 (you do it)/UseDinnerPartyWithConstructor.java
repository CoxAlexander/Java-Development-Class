//UseDinnerPartyWithConstructor.java
//9/18/2024
//Alexander Cox

public class UseDinnerPartyWithConstructor {
    public static void main(String[] args) {
        DinnerPartyWithConstructor aDinnnerParty = new DinnerPartyWithConstructor();
    }
}